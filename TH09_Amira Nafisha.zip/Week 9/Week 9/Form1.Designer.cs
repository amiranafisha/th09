﻿namespace Week_9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView_TokoPakaian = new System.Windows.Forms.DataGridView();
            this.lb_SubTotal = new System.Windows.Forms.Label();
            this.lb_Total = new System.Windows.Forms.Label();
            this.textBox_SubTotal = new System.Windows.Forms.TextBox();
            this.textBox_Total = new System.Windows.Forms.TextBox();
            this.pictureBox_KerahBulat = new System.Windows.Forms.PictureBox();
            this.panel_Tshirt = new System.Windows.Forms.Panel();
            this.btn_AddToCartVNeck = new System.Windows.Forms.Button();
            this.btn_AddToCartAlRism = new System.Windows.Forms.Button();
            this.btn_AddToCart_KerahBulat = new System.Windows.Forms.Button();
            this.lb_HargaVNeck = new System.Windows.Forms.Label();
            this.lb_HargaAlRism = new System.Windows.Forms.Label();
            this.lb_HargaKerahBulat = new System.Windows.Forms.Label();
            this.lb_VNeck = new System.Windows.Forms.Label();
            this.lb_AlRism = new System.Windows.Forms.Label();
            this.lb_KerahBulat = new System.Windows.Forms.Label();
            this.pictureBox_VNeck = new System.Windows.Forms.PictureBox();
            this.pictureBox_AlRism = new System.Windows.Forms.PictureBox();
            this.lb_Upload = new System.Windows.Forms.Label();
            this.btn_Upload = new System.Windows.Forms.Button();
            this.pictureBox_UploadImage = new System.Windows.Forms.PictureBox();
            this.lb_ItemName = new System.Windows.Forms.Label();
            this.lb_ItemPrice = new System.Windows.Forms.Label();
            this.btn_AddToCartUpload = new System.Windows.Forms.Button();
            this.textBox_ItemName = new System.Windows.Forms.TextBox();
            this.textBox_ItemPrice = new System.Windows.Forms.TextBox();
            this.panel_Upload = new System.Windows.Forms.Panel();
            this.panel_Shirt = new System.Windows.Forms.Panel();
            this.btn_AddToCart_Grey = new System.Windows.Forms.Button();
            this.btn_AddToCart_Red = new System.Windows.Forms.Button();
            this.btn_AddToCart_DarkBlue = new System.Windows.Forms.Button();
            this.lb_HargaGrey = new System.Windows.Forms.Label();
            this.lb_HargaRed = new System.Windows.Forms.Label();
            this.lb_HargaDarkBlue = new System.Windows.Forms.Label();
            this.lb_Grey = new System.Windows.Forms.Label();
            this.lb_Red = new System.Windows.Forms.Label();
            this.lb_DarkBlue = new System.Windows.Forms.Label();
            this.pictureBox_Grey = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.panel_Pants = new System.Windows.Forms.Panel();
            this.btn_AddToCart_Green = new System.Windows.Forms.Button();
            this.btn_AddToCart_Pink = new System.Windows.Forms.Button();
            this.btn_AddToCart_Yellow = new System.Windows.Forms.Button();
            this.lb_HargaGreen = new System.Windows.Forms.Label();
            this.lb_HargaPink = new System.Windows.Forms.Label();
            this.lb_HargaYellow = new System.Windows.Forms.Label();
            this.lb_Green = new System.Windows.Forms.Label();
            this.lb_Pink = new System.Windows.Forms.Label();
            this.lb_Yellow = new System.Windows.Forms.Label();
            this.pictureBox_Green = new System.Windows.Forms.PictureBox();
            this.pictureBox_Pink = new System.Windows.Forms.PictureBox();
            this.pictureBox_Yellow = new System.Windows.Forms.PictureBox();
            this.panel_Shoes = new System.Windows.Forms.Panel();
            this.btn_AddToCart_SneakersPink = new System.Windows.Forms.Button();
            this.btn_SneakersCoklat = new System.Windows.Forms.Button();
            this.btn_AddToCard_SneakersPutih = new System.Windows.Forms.Button();
            this.lb_HargaSnekaersPink = new System.Windows.Forms.Label();
            this.lb_HargaSneakersCoklat = new System.Windows.Forms.Label();
            this.lb_HargaSneakersPutih = new System.Windows.Forms.Label();
            this.lb_SneakersPink = new System.Windows.Forms.Label();
            this.lb_SneakersCoklat = new System.Windows.Forms.Label();
            this.lb_SneakersWhite = new System.Windows.Forms.Label();
            this.pictureBox_SepatuPink = new System.Windows.Forms.PictureBox();
            this.pictureBox_SepatuCoklat = new System.Windows.Forms.PictureBox();
            this.pictureBox_SepatuPutih = new System.Windows.Forms.PictureBox();
            this.panel_longPants = new System.Windows.Forms.Panel();
            this.btn_AddToCart_LongPantsGrey = new System.Windows.Forms.Button();
            this.btn_AddToCart_Brown = new System.Windows.Forms.Button();
            this.btn_AddToCart_Black = new System.Windows.Forms.Button();
            this.lb_HargaLongPantsGrey = new System.Windows.Forms.Label();
            this.lb_HargaBrown = new System.Windows.Forms.Label();
            this.lb_HargaBlack = new System.Windows.Forms.Label();
            this.lb_longPantsGrey = new System.Windows.Forms.Label();
            this.lb_Brown = new System.Windows.Forms.Label();
            this.lb_Black = new System.Windows.Forms.Label();
            this.pictureBox_longPants_Grey = new System.Windows.Forms.PictureBox();
            this.pictureBox_longPantsBrown = new System.Windows.Forms.PictureBox();
            this.pictureBox_Black = new System.Windows.Forms.PictureBox();
            this.panel_jewelleries = new System.Windows.Forms.Panel();
            this.btn_AddToCart_Gold = new System.Windows.Forms.Button();
            this.btn_AddToCartNecklaceChain = new System.Windows.Forms.Button();
            this.btn_AddToCart_Silver = new System.Windows.Forms.Button();
            this.lb_HargaGold = new System.Windows.Forms.Label();
            this.lb_necklaceChain = new System.Windows.Forms.Label();
            this.lb_HargaSilver = new System.Windows.Forms.Label();
            this.lb_Gold = new System.Windows.Forms.Label();
            this.lb_Chain = new System.Windows.Forms.Label();
            this.lb_Silver = new System.Windows.Forms.Label();
            this.lb_GoldNecklaces = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox_Silver = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_TokoPakaian)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_KerahBulat)).BeginInit();
            this.panel_Tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_VNeck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AlRism)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UploadImage)).BeginInit();
            this.panel_Upload.SuspendLayout();
            this.panel_Shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Grey)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel_Pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Green)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Pink)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Yellow)).BeginInit();
            this.panel_Shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SepatuPink)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SepatuCoklat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SepatuPutih)).BeginInit();
            this.panel_longPants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longPants_Grey)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longPantsBrown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Black)).BeginInit();
            this.panel_jewelleries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lb_GoldNecklaces)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Silver)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1217, 36);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(119, 29);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(195, 34);
            this.jewelleriesToolStripMenuItem.Text = "Jewelleries";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dataGridView_TokoPakaian
            // 
            this.dataGridView_TokoPakaian.AllowUserToAddRows = false;
            this.dataGridView_TokoPakaian.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView_TokoPakaian.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_TokoPakaian.Location = new System.Drawing.Point(638, 36);
            this.dataGridView_TokoPakaian.Name = "dataGridView_TokoPakaian";
            this.dataGridView_TokoPakaian.RowHeadersVisible = false;
            this.dataGridView_TokoPakaian.RowHeadersWidth = 62;
            this.dataGridView_TokoPakaian.RowTemplate.Height = 28;
            this.dataGridView_TokoPakaian.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_TokoPakaian.Size = new System.Drawing.Size(567, 255);
            this.dataGridView_TokoPakaian.TabIndex = 1;
            this.dataGridView_TokoPakaian.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_TokoPakaian_CellContentClick);
            // 
            // lb_SubTotal
            // 
            this.lb_SubTotal.AutoSize = true;
            this.lb_SubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_SubTotal.Location = new System.Drawing.Point(704, 308);
            this.lb_SubTotal.Name = "lb_SubTotal";
            this.lb_SubTotal.Size = new System.Drawing.Size(135, 29);
            this.lb_SubTotal.TabIndex = 2;
            this.lb_SubTotal.Text = "Sub-Total:";
            // 
            // lb_Total
            // 
            this.lb_Total.AutoSize = true;
            this.lb_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Total.Location = new System.Drawing.Point(704, 346);
            this.lb_Total.Name = "lb_Total";
            this.lb_Total.Size = new System.Drawing.Size(80, 29);
            this.lb_Total.TabIndex = 3;
            this.lb_Total.Text = "Total:";
            // 
            // textBox_SubTotal
            // 
            this.textBox_SubTotal.Location = new System.Drawing.Point(846, 310);
            this.textBox_SubTotal.Name = "textBox_SubTotal";
            this.textBox_SubTotal.Size = new System.Drawing.Size(170, 26);
            this.textBox_SubTotal.TabIndex = 4;
            // 
            // textBox_Total
            // 
            this.textBox_Total.Location = new System.Drawing.Point(846, 346);
            this.textBox_Total.Name = "textBox_Total";
            this.textBox_Total.Size = new System.Drawing.Size(170, 26);
            this.textBox_Total.TabIndex = 5;
            // 
            // pictureBox_KerahBulat
            // 
            this.pictureBox_KerahBulat.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_KerahBulat.Image")));
            this.pictureBox_KerahBulat.InitialImage = null;
            this.pictureBox_KerahBulat.Location = new System.Drawing.Point(22, 15);
            this.pictureBox_KerahBulat.Name = "pictureBox_KerahBulat";
            this.pictureBox_KerahBulat.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_KerahBulat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_KerahBulat.TabIndex = 6;
            this.pictureBox_KerahBulat.TabStop = false;
            // 
            // panel_Tshirt
            // 
            this.panel_Tshirt.Controls.Add(this.btn_AddToCartVNeck);
            this.panel_Tshirt.Controls.Add(this.btn_AddToCartAlRism);
            this.panel_Tshirt.Controls.Add(this.btn_AddToCart_KerahBulat);
            this.panel_Tshirt.Controls.Add(this.lb_HargaVNeck);
            this.panel_Tshirt.Controls.Add(this.lb_HargaAlRism);
            this.panel_Tshirt.Controls.Add(this.lb_HargaKerahBulat);
            this.panel_Tshirt.Controls.Add(this.lb_VNeck);
            this.panel_Tshirt.Controls.Add(this.lb_AlRism);
            this.panel_Tshirt.Controls.Add(this.lb_KerahBulat);
            this.panel_Tshirt.Controls.Add(this.pictureBox_VNeck);
            this.panel_Tshirt.Controls.Add(this.pictureBox_AlRism);
            this.panel_Tshirt.Controls.Add(this.pictureBox_KerahBulat);
            this.panel_Tshirt.Location = new System.Drawing.Point(27, 49);
            this.panel_Tshirt.Name = "panel_Tshirt";
            this.panel_Tshirt.Size = new System.Drawing.Size(567, 343);
            this.panel_Tshirt.TabIndex = 7;
            // 
            // btn_AddToCartVNeck
            // 
            this.btn_AddToCartVNeck.Location = new System.Drawing.Point(368, 281);
            this.btn_AddToCartVNeck.Name = "btn_AddToCartVNeck";
            this.btn_AddToCartVNeck.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCartVNeck.TabIndex = 17;
            this.btn_AddToCartVNeck.Text = "Add to Cart";
            this.btn_AddToCartVNeck.UseVisualStyleBackColor = true;
            this.btn_AddToCartVNeck.Click += new System.EventHandler(this.btn_AddToCartVNeck_Click);
            // 
            // btn_AddToCartAlRism
            // 
            this.btn_AddToCartAlRism.Location = new System.Drawing.Point(194, 281);
            this.btn_AddToCartAlRism.Name = "btn_AddToCartAlRism";
            this.btn_AddToCartAlRism.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCartAlRism.TabIndex = 16;
            this.btn_AddToCartAlRism.Text = "Add to Cart";
            this.btn_AddToCartAlRism.UseVisualStyleBackColor = true;
            this.btn_AddToCartAlRism.Click += new System.EventHandler(this.btn_AddToCartAlRism_Click);
            // 
            // btn_AddToCart_KerahBulat
            // 
            this.btn_AddToCart_KerahBulat.Location = new System.Drawing.Point(22, 281);
            this.btn_AddToCart_KerahBulat.Name = "btn_AddToCart_KerahBulat";
            this.btn_AddToCart_KerahBulat.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_KerahBulat.TabIndex = 15;
            this.btn_AddToCart_KerahBulat.Text = "Add to Cart";
            this.btn_AddToCart_KerahBulat.UseVisualStyleBackColor = true;
            this.btn_AddToCart_KerahBulat.Click += new System.EventHandler(this.btn_AddToCart_KerahBulat_Click);
            // 
            // lb_HargaVNeck
            // 
            this.lb_HargaVNeck.AutoSize = true;
            this.lb_HargaVNeck.Location = new System.Drawing.Point(364, 248);
            this.lb_HargaVNeck.Name = "lb_HargaVNeck";
            this.lb_HargaVNeck.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaVNeck.TabIndex = 14;
            this.lb_HargaVNeck.Text = "Rp. 170.000,-";
            // 
            // lb_HargaAlRism
            // 
            this.lb_HargaAlRism.AutoSize = true;
            this.lb_HargaAlRism.Location = new System.Drawing.Point(195, 248);
            this.lb_HargaAlRism.Name = "lb_HargaAlRism";
            this.lb_HargaAlRism.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaAlRism.TabIndex = 13;
            this.lb_HargaAlRism.Text = "Rp. 150.000,-";
            // 
            // lb_HargaKerahBulat
            // 
            this.lb_HargaKerahBulat.AutoSize = true;
            this.lb_HargaKerahBulat.Location = new System.Drawing.Point(18, 248);
            this.lb_HargaKerahBulat.Name = "lb_HargaKerahBulat";
            this.lb_HargaKerahBulat.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaKerahBulat.TabIndex = 12;
            this.lb_HargaKerahBulat.Text = "Rp. 120.000,-";
            // 
            // lb_VNeck
            // 
            this.lb_VNeck.AutoSize = true;
            this.lb_VNeck.Location = new System.Drawing.Point(364, 208);
            this.lb_VNeck.Name = "lb_VNeck";
            this.lb_VNeck.Size = new System.Drawing.Size(107, 20);
            this.lb_VNeck.TabIndex = 11;
            this.lb_VNeck.Text = "T-Shirt VNeck";
            // 
            // lb_AlRism
            // 
            this.lb_AlRism.AutoSize = true;
            this.lb_AlRism.Location = new System.Drawing.Point(190, 208);
            this.lb_AlRism.Name = "lb_AlRism";
            this.lb_AlRism.Size = new System.Drawing.Size(110, 20);
            this.lb_AlRism.TabIndex = 10;
            this.lb_AlRism.Text = "AlRism T-Shirt";
            // 
            // lb_KerahBulat
            // 
            this.lb_KerahBulat.AutoSize = true;
            this.lb_KerahBulat.Location = new System.Drawing.Point(18, 208);
            this.lb_KerahBulat.Name = "lb_KerahBulat";
            this.lb_KerahBulat.Size = new System.Drawing.Size(143, 20);
            this.lb_KerahBulat.TabIndex = 9;
            this.lb_KerahBulat.Text = "T-Shirt Kerah Bulat";
            // 
            // pictureBox_VNeck
            // 
            this.pictureBox_VNeck.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_VNeck.Image")));
            this.pictureBox_VNeck.Location = new System.Drawing.Point(368, 15);
            this.pictureBox_VNeck.Name = "pictureBox_VNeck";
            this.pictureBox_VNeck.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_VNeck.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_VNeck.TabIndex = 8;
            this.pictureBox_VNeck.TabStop = false;
            // 
            // pictureBox_AlRism
            // 
            this.pictureBox_AlRism.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_AlRism.Image")));
            this.pictureBox_AlRism.Location = new System.Drawing.Point(194, 15);
            this.pictureBox_AlRism.Name = "pictureBox_AlRism";
            this.pictureBox_AlRism.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_AlRism.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_AlRism.TabIndex = 7;
            this.pictureBox_AlRism.TabStop = false;
            // 
            // lb_Upload
            // 
            this.lb_Upload.AutoSize = true;
            this.lb_Upload.Location = new System.Drawing.Point(105, 21);
            this.lb_Upload.Name = "lb_Upload";
            this.lb_Upload.Size = new System.Drawing.Size(109, 20);
            this.lb_Upload.TabIndex = 8;
            this.lb_Upload.Text = "Upload Image";
            // 
            // btn_Upload
            // 
            this.btn_Upload.Location = new System.Drawing.Point(246, 12);
            this.btn_Upload.Name = "btn_Upload";
            this.btn_Upload.Size = new System.Drawing.Size(101, 39);
            this.btn_Upload.TabIndex = 9;
            this.btn_Upload.Text = "Upload";
            this.btn_Upload.UseVisualStyleBackColor = true;
            this.btn_Upload.Click += new System.EventHandler(this.btn_Upload_Click);
            // 
            // pictureBox_UploadImage
            // 
            this.pictureBox_UploadImage.Location = new System.Drawing.Point(107, 66);
            this.pictureBox_UploadImage.Name = "pictureBox_UploadImage";
            this.pictureBox_UploadImage.Size = new System.Drawing.Size(127, 214);
            this.pictureBox_UploadImage.TabIndex = 18;
            this.pictureBox_UploadImage.TabStop = false;
            // 
            // lb_ItemName
            // 
            this.lb_ItemName.AutoSize = true;
            this.lb_ItemName.Location = new System.Drawing.Point(256, 66);
            this.lb_ItemName.Name = "lb_ItemName";
            this.lb_ItemName.Size = new System.Drawing.Size(91, 20);
            this.lb_ItemName.TabIndex = 18;
            this.lb_ItemName.Text = "Item Name:";
            // 
            // lb_ItemPrice
            // 
            this.lb_ItemPrice.AutoSize = true;
            this.lb_ItemPrice.Location = new System.Drawing.Point(256, 145);
            this.lb_ItemPrice.Name = "lb_ItemPrice";
            this.lb_ItemPrice.Size = new System.Drawing.Size(84, 20);
            this.lb_ItemPrice.TabIndex = 19;
            this.lb_ItemPrice.Text = "Item Price:";
            // 
            // btn_AddToCartUpload
            // 
            this.btn_AddToCartUpload.Location = new System.Drawing.Point(260, 228);
            this.btn_AddToCartUpload.Name = "btn_AddToCartUpload";
            this.btn_AddToCartUpload.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCartUpload.TabIndex = 18;
            this.btn_AddToCartUpload.Text = "Add to Cart";
            this.btn_AddToCartUpload.UseVisualStyleBackColor = true;
            this.btn_AddToCartUpload.Click += new System.EventHandler(this.btn_AddToCartUpload_Click);
            // 
            // textBox_ItemName
            // 
            this.textBox_ItemName.Location = new System.Drawing.Point(260, 98);
            this.textBox_ItemName.Name = "textBox_ItemName";
            this.textBox_ItemName.Size = new System.Drawing.Size(166, 26);
            this.textBox_ItemName.TabIndex = 20;
            this.textBox_ItemName.TextChanged += new System.EventHandler(this.textBox_ItemName_TextChanged);
            // 
            // textBox_ItemPrice
            // 
            this.textBox_ItemPrice.Location = new System.Drawing.Point(260, 180);
            this.textBox_ItemPrice.Name = "textBox_ItemPrice";
            this.textBox_ItemPrice.Size = new System.Drawing.Size(166, 26);
            this.textBox_ItemPrice.TabIndex = 21;
            this.textBox_ItemPrice.TextChanged += new System.EventHandler(this.textBox_ItemPrice_TextChanged);
            // 
            // panel_Upload
            // 
            this.panel_Upload.Controls.Add(this.btn_Upload);
            this.panel_Upload.Controls.Add(this.textBox_ItemPrice);
            this.panel_Upload.Controls.Add(this.lb_Upload);
            this.panel_Upload.Controls.Add(this.textBox_ItemName);
            this.panel_Upload.Controls.Add(this.pictureBox_UploadImage);
            this.panel_Upload.Controls.Add(this.btn_AddToCartUpload);
            this.panel_Upload.Controls.Add(this.lb_ItemName);
            this.panel_Upload.Controls.Add(this.lb_ItemPrice);
            this.panel_Upload.Location = new System.Drawing.Point(30, 49);
            this.panel_Upload.Name = "panel_Upload";
            this.panel_Upload.Size = new System.Drawing.Size(671, 424);
            this.panel_Upload.TabIndex = 22;
            // 
            // panel_Shirt
            // 
            this.panel_Shirt.Controls.Add(this.btn_AddToCart_Grey);
            this.panel_Shirt.Controls.Add(this.btn_AddToCart_Red);
            this.panel_Shirt.Controls.Add(this.btn_AddToCart_DarkBlue);
            this.panel_Shirt.Controls.Add(this.lb_HargaGrey);
            this.panel_Shirt.Controls.Add(this.lb_HargaRed);
            this.panel_Shirt.Controls.Add(this.lb_HargaDarkBlue);
            this.panel_Shirt.Controls.Add(this.lb_Grey);
            this.panel_Shirt.Controls.Add(this.lb_Red);
            this.panel_Shirt.Controls.Add(this.lb_DarkBlue);
            this.panel_Shirt.Controls.Add(this.pictureBox_Grey);
            this.panel_Shirt.Controls.Add(this.pictureBox3);
            this.panel_Shirt.Controls.Add(this.pictureBox4);
            this.panel_Shirt.Location = new System.Drawing.Point(27, 49);
            this.panel_Shirt.Name = "panel_Shirt";
            this.panel_Shirt.Size = new System.Drawing.Size(567, 343);
            this.panel_Shirt.TabIndex = 23;
            // 
            // btn_AddToCart_Grey
            // 
            this.btn_AddToCart_Grey.Location = new System.Drawing.Point(368, 281);
            this.btn_AddToCart_Grey.Name = "btn_AddToCart_Grey";
            this.btn_AddToCart_Grey.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Grey.TabIndex = 17;
            this.btn_AddToCart_Grey.Text = "Add to Cart";
            this.btn_AddToCart_Grey.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Grey.Click += new System.EventHandler(this.btn_AddToCart_Grey_Click);
            // 
            // btn_AddToCart_Red
            // 
            this.btn_AddToCart_Red.Location = new System.Drawing.Point(194, 281);
            this.btn_AddToCart_Red.Name = "btn_AddToCart_Red";
            this.btn_AddToCart_Red.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Red.TabIndex = 16;
            this.btn_AddToCart_Red.Text = "Add to Cart";
            this.btn_AddToCart_Red.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Red.Click += new System.EventHandler(this.btn_AddToCart_Red_Click);
            // 
            // btn_AddToCart_DarkBlue
            // 
            this.btn_AddToCart_DarkBlue.Location = new System.Drawing.Point(22, 281);
            this.btn_AddToCart_DarkBlue.Name = "btn_AddToCart_DarkBlue";
            this.btn_AddToCart_DarkBlue.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_DarkBlue.TabIndex = 15;
            this.btn_AddToCart_DarkBlue.Text = "Add to Cart";
            this.btn_AddToCart_DarkBlue.UseVisualStyleBackColor = true;
            this.btn_AddToCart_DarkBlue.Click += new System.EventHandler(this.btn_AddToCart_DarkBlue_Click);
            // 
            // lb_HargaGrey
            // 
            this.lb_HargaGrey.AutoSize = true;
            this.lb_HargaGrey.Location = new System.Drawing.Point(364, 248);
            this.lb_HargaGrey.Name = "lb_HargaGrey";
            this.lb_HargaGrey.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaGrey.TabIndex = 14;
            this.lb_HargaGrey.Text = "Rp. 100.000,-";
            // 
            // lb_HargaRed
            // 
            this.lb_HargaRed.AutoSize = true;
            this.lb_HargaRed.Location = new System.Drawing.Point(195, 248);
            this.lb_HargaRed.Name = "lb_HargaRed";
            this.lb_HargaRed.Size = new System.Drawing.Size(96, 20);
            this.lb_HargaRed.TabIndex = 13;
            this.lb_HargaRed.Text = "Rp. 42.500,-";
            // 
            // lb_HargaDarkBlue
            // 
            this.lb_HargaDarkBlue.AutoSize = true;
            this.lb_HargaDarkBlue.Location = new System.Drawing.Point(18, 248);
            this.lb_HargaDarkBlue.Name = "lb_HargaDarkBlue";
            this.lb_HargaDarkBlue.Size = new System.Drawing.Size(96, 20);
            this.lb_HargaDarkBlue.TabIndex = 12;
            this.lb_HargaDarkBlue.Text = "Rp. 50.000,-";
            // 
            // lb_Grey
            // 
            this.lb_Grey.AutoSize = true;
            this.lb_Grey.Location = new System.Drawing.Point(364, 208);
            this.lb_Grey.Name = "lb_Grey";
            this.lb_Grey.Size = new System.Drawing.Size(115, 20);
            this.lb_Grey.TabIndex = 11;
            this.lb_Grey.Text = "Polo Shirt Grey";
            // 
            // lb_Red
            // 
            this.lb_Red.AutoSize = true;
            this.lb_Red.Location = new System.Drawing.Point(190, 208);
            this.lb_Red.Name = "lb_Red";
            this.lb_Red.Size = new System.Drawing.Size(111, 20);
            this.lb_Red.TabIndex = 10;
            this.lb_Red.Text = "Polo Shirt Red";
            // 
            // lb_DarkBlue
            // 
            this.lb_DarkBlue.AutoSize = true;
            this.lb_DarkBlue.Location = new System.Drawing.Point(18, 208);
            this.lb_DarkBlue.Name = "lb_DarkBlue";
            this.lb_DarkBlue.Size = new System.Drawing.Size(147, 20);
            this.lb_DarkBlue.TabIndex = 9;
            this.lb_DarkBlue.Text = "Polo Shirt DarkBlue";
            // 
            // pictureBox_Grey
            // 
            this.pictureBox_Grey.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Grey.Image")));
            this.pictureBox_Grey.Location = new System.Drawing.Point(368, 15);
            this.pictureBox_Grey.Name = "pictureBox_Grey";
            this.pictureBox_Grey.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_Grey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Grey.TabIndex = 8;
            this.pictureBox_Grey.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(194, 15);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(127, 175);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.InitialImage = null;
            this.pictureBox4.Location = new System.Drawing.Point(22, 15);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(127, 175);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // panel_Pants
            // 
            this.panel_Pants.Controls.Add(this.btn_AddToCart_Green);
            this.panel_Pants.Controls.Add(this.btn_AddToCart_Pink);
            this.panel_Pants.Controls.Add(this.btn_AddToCart_Yellow);
            this.panel_Pants.Controls.Add(this.lb_HargaGreen);
            this.panel_Pants.Controls.Add(this.lb_HargaPink);
            this.panel_Pants.Controls.Add(this.lb_HargaYellow);
            this.panel_Pants.Controls.Add(this.lb_Green);
            this.panel_Pants.Controls.Add(this.lb_Pink);
            this.panel_Pants.Controls.Add(this.lb_Yellow);
            this.panel_Pants.Controls.Add(this.pictureBox_Green);
            this.panel_Pants.Controls.Add(this.pictureBox_Pink);
            this.panel_Pants.Controls.Add(this.pictureBox_Yellow);
            this.panel_Pants.Location = new System.Drawing.Point(27, 49);
            this.panel_Pants.Name = "panel_Pants";
            this.panel_Pants.Size = new System.Drawing.Size(567, 343);
            this.panel_Pants.TabIndex = 24;
            // 
            // btn_AddToCart_Green
            // 
            this.btn_AddToCart_Green.Location = new System.Drawing.Point(368, 281);
            this.btn_AddToCart_Green.Name = "btn_AddToCart_Green";
            this.btn_AddToCart_Green.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Green.TabIndex = 17;
            this.btn_AddToCart_Green.Text = "Add to Cart";
            this.btn_AddToCart_Green.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Green.Click += new System.EventHandler(this.btn_AddToCart_Green_Click);
            // 
            // btn_AddToCart_Pink
            // 
            this.btn_AddToCart_Pink.Location = new System.Drawing.Point(194, 281);
            this.btn_AddToCart_Pink.Name = "btn_AddToCart_Pink";
            this.btn_AddToCart_Pink.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Pink.TabIndex = 16;
            this.btn_AddToCart_Pink.Text = "Add to Cart";
            this.btn_AddToCart_Pink.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Pink.Click += new System.EventHandler(this.btn_AddToCart_Pink_Click);
            // 
            // btn_AddToCart_Yellow
            // 
            this.btn_AddToCart_Yellow.Location = new System.Drawing.Point(22, 281);
            this.btn_AddToCart_Yellow.Name = "btn_AddToCart_Yellow";
            this.btn_AddToCart_Yellow.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Yellow.TabIndex = 15;
            this.btn_AddToCart_Yellow.Text = "Add to Cart";
            this.btn_AddToCart_Yellow.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Yellow.Click += new System.EventHandler(this.btn_AddToCart_Yellow_Click);
            // 
            // lb_HargaGreen
            // 
            this.lb_HargaGreen.AutoSize = true;
            this.lb_HargaGreen.Location = new System.Drawing.Point(364, 248);
            this.lb_HargaGreen.Name = "lb_HargaGreen";
            this.lb_HargaGreen.Size = new System.Drawing.Size(96, 20);
            this.lb_HargaGreen.TabIndex = 14;
            this.lb_HargaGreen.Text = "Rp. 75.000,-";
            // 
            // lb_HargaPink
            // 
            this.lb_HargaPink.AutoSize = true;
            this.lb_HargaPink.Location = new System.Drawing.Point(195, 248);
            this.lb_HargaPink.Name = "lb_HargaPink";
            this.lb_HargaPink.Size = new System.Drawing.Size(96, 20);
            this.lb_HargaPink.TabIndex = 13;
            this.lb_HargaPink.Text = "Rp. 75.000,-";
            // 
            // lb_HargaYellow
            // 
            this.lb_HargaYellow.AutoSize = true;
            this.lb_HargaYellow.Location = new System.Drawing.Point(18, 248);
            this.lb_HargaYellow.Name = "lb_HargaYellow";
            this.lb_HargaYellow.Size = new System.Drawing.Size(96, 20);
            this.lb_HargaYellow.TabIndex = 12;
            this.lb_HargaYellow.Text = "Rp. 75.000,-";
            // 
            // lb_Green
            // 
            this.lb_Green.AutoSize = true;
            this.lb_Green.Location = new System.Drawing.Point(364, 208);
            this.lb_Green.Name = "lb_Green";
            this.lb_Green.Size = new System.Drawing.Size(99, 20);
            this.lb_Green.TabIndex = 11;
            this.lb_Green.Text = "Pants Green";
            // 
            // lb_Pink
            // 
            this.lb_Pink.AutoSize = true;
            this.lb_Pink.Location = new System.Drawing.Point(190, 208);
            this.lb_Pink.Name = "lb_Pink";
            this.lb_Pink.Size = new System.Drawing.Size(84, 20);
            this.lb_Pink.TabIndex = 10;
            this.lb_Pink.Text = "Pants Pink";
            // 
            // lb_Yellow
            // 
            this.lb_Yellow.AutoSize = true;
            this.lb_Yellow.Location = new System.Drawing.Point(18, 208);
            this.lb_Yellow.Name = "lb_Yellow";
            this.lb_Yellow.Size = new System.Drawing.Size(100, 20);
            this.lb_Yellow.TabIndex = 9;
            this.lb_Yellow.Text = "Pants Yellow";
            // 
            // pictureBox_Green
            // 
            this.pictureBox_Green.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Green.Image")));
            this.pictureBox_Green.Location = new System.Drawing.Point(368, 15);
            this.pictureBox_Green.Name = "pictureBox_Green";
            this.pictureBox_Green.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_Green.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Green.TabIndex = 8;
            this.pictureBox_Green.TabStop = false;
            // 
            // pictureBox_Pink
            // 
            this.pictureBox_Pink.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Pink.Image")));
            this.pictureBox_Pink.Location = new System.Drawing.Point(194, 15);
            this.pictureBox_Pink.Name = "pictureBox_Pink";
            this.pictureBox_Pink.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_Pink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Pink.TabIndex = 7;
            this.pictureBox_Pink.TabStop = false;
            // 
            // pictureBox_Yellow
            // 
            this.pictureBox_Yellow.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Yellow.Image")));
            this.pictureBox_Yellow.InitialImage = null;
            this.pictureBox_Yellow.Location = new System.Drawing.Point(22, 15);
            this.pictureBox_Yellow.Name = "pictureBox_Yellow";
            this.pictureBox_Yellow.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_Yellow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Yellow.TabIndex = 6;
            this.pictureBox_Yellow.TabStop = false;
            // 
            // panel_Shoes
            // 
            this.panel_Shoes.Controls.Add(this.btn_AddToCart_SneakersPink);
            this.panel_Shoes.Controls.Add(this.btn_SneakersCoklat);
            this.panel_Shoes.Controls.Add(this.btn_AddToCard_SneakersPutih);
            this.panel_Shoes.Controls.Add(this.lb_HargaSnekaersPink);
            this.panel_Shoes.Controls.Add(this.lb_HargaSneakersCoklat);
            this.panel_Shoes.Controls.Add(this.lb_HargaSneakersPutih);
            this.panel_Shoes.Controls.Add(this.lb_SneakersPink);
            this.panel_Shoes.Controls.Add(this.lb_SneakersCoklat);
            this.panel_Shoes.Controls.Add(this.lb_SneakersWhite);
            this.panel_Shoes.Controls.Add(this.pictureBox_SepatuPink);
            this.panel_Shoes.Controls.Add(this.pictureBox_SepatuCoklat);
            this.panel_Shoes.Controls.Add(this.pictureBox_SepatuPutih);
            this.panel_Shoes.Location = new System.Drawing.Point(27, 49);
            this.panel_Shoes.Name = "panel_Shoes";
            this.panel_Shoes.Size = new System.Drawing.Size(558, 346);
            this.panel_Shoes.TabIndex = 18;
            // 
            // btn_AddToCart_SneakersPink
            // 
            this.btn_AddToCart_SneakersPink.Location = new System.Drawing.Point(368, 281);
            this.btn_AddToCart_SneakersPink.Name = "btn_AddToCart_SneakersPink";
            this.btn_AddToCart_SneakersPink.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_SneakersPink.TabIndex = 17;
            this.btn_AddToCart_SneakersPink.Text = "Add to Cart";
            this.btn_AddToCart_SneakersPink.UseVisualStyleBackColor = true;
            this.btn_AddToCart_SneakersPink.Click += new System.EventHandler(this.btn_AddToCart_SneakersPink_Click);
            // 
            // btn_SneakersCoklat
            // 
            this.btn_SneakersCoklat.Location = new System.Drawing.Point(194, 281);
            this.btn_SneakersCoklat.Name = "btn_SneakersCoklat";
            this.btn_SneakersCoklat.Size = new System.Drawing.Size(101, 52);
            this.btn_SneakersCoklat.TabIndex = 16;
            this.btn_SneakersCoklat.Text = "Add to Cart";
            this.btn_SneakersCoklat.UseVisualStyleBackColor = true;
            this.btn_SneakersCoklat.Click += new System.EventHandler(this.btn_SneakersCoklat_Click);
            // 
            // btn_AddToCard_SneakersPutih
            // 
            this.btn_AddToCard_SneakersPutih.Location = new System.Drawing.Point(22, 281);
            this.btn_AddToCard_SneakersPutih.Name = "btn_AddToCard_SneakersPutih";
            this.btn_AddToCard_SneakersPutih.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCard_SneakersPutih.TabIndex = 15;
            this.btn_AddToCard_SneakersPutih.Text = "Add to Cart";
            this.btn_AddToCard_SneakersPutih.UseVisualStyleBackColor = true;
            this.btn_AddToCard_SneakersPutih.Click += new System.EventHandler(this.btn_AddToCard_SneakersPutih_Click);
            // 
            // lb_HargaSnekaersPink
            // 
            this.lb_HargaSnekaersPink.AutoSize = true;
            this.lb_HargaSnekaersPink.Location = new System.Drawing.Point(364, 248);
            this.lb_HargaSnekaersPink.Name = "lb_HargaSnekaersPink";
            this.lb_HargaSnekaersPink.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaSnekaersPink.TabIndex = 14;
            this.lb_HargaSnekaersPink.Text = "Rp. 300.000,-";
            // 
            // lb_HargaSneakersCoklat
            // 
            this.lb_HargaSneakersCoklat.AutoSize = true;
            this.lb_HargaSneakersCoklat.Location = new System.Drawing.Point(195, 248);
            this.lb_HargaSneakersCoklat.Name = "lb_HargaSneakersCoklat";
            this.lb_HargaSneakersCoklat.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaSneakersCoklat.TabIndex = 13;
            this.lb_HargaSneakersCoklat.Text = "Rp. 250.000,-";
            // 
            // lb_HargaSneakersPutih
            // 
            this.lb_HargaSneakersPutih.AutoSize = true;
            this.lb_HargaSneakersPutih.Location = new System.Drawing.Point(18, 248);
            this.lb_HargaSneakersPutih.Name = "lb_HargaSneakersPutih";
            this.lb_HargaSneakersPutih.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaSneakersPutih.TabIndex = 12;
            this.lb_HargaSneakersPutih.Text = "Rp. 200.000,-";
            // 
            // lb_SneakersPink
            // 
            this.lb_SneakersPink.AutoSize = true;
            this.lb_SneakersPink.Location = new System.Drawing.Point(364, 208);
            this.lb_SneakersPink.Name = "lb_SneakersPink";
            this.lb_SneakersPink.Size = new System.Drawing.Size(111, 20);
            this.lb_SneakersPink.TabIndex = 11;
            this.lb_SneakersPink.Text = "Sneakers Pink";
            // 
            // lb_SneakersCoklat
            // 
            this.lb_SneakersCoklat.AutoSize = true;
            this.lb_SneakersCoklat.Location = new System.Drawing.Point(190, 208);
            this.lb_SneakersCoklat.Name = "lb_SneakersCoklat";
            this.lb_SneakersCoklat.Size = new System.Drawing.Size(126, 20);
            this.lb_SneakersCoklat.TabIndex = 10;
            this.lb_SneakersCoklat.Text = "Sneakers Coklat";
            // 
            // lb_SneakersWhite
            // 
            this.lb_SneakersWhite.AutoSize = true;
            this.lb_SneakersWhite.Location = new System.Drawing.Point(18, 208);
            this.lb_SneakersWhite.Name = "lb_SneakersWhite";
            this.lb_SneakersWhite.Size = new System.Drawing.Size(117, 20);
            this.lb_SneakersWhite.TabIndex = 9;
            this.lb_SneakersWhite.Text = "Sneakers Putih";
            // 
            // pictureBox_SepatuPink
            // 
            this.pictureBox_SepatuPink.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_SepatuPink.Image")));
            this.pictureBox_SepatuPink.Location = new System.Drawing.Point(368, 15);
            this.pictureBox_SepatuPink.Name = "pictureBox_SepatuPink";
            this.pictureBox_SepatuPink.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_SepatuPink.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_SepatuPink.TabIndex = 8;
            this.pictureBox_SepatuPink.TabStop = false;
            // 
            // pictureBox_SepatuCoklat
            // 
            this.pictureBox_SepatuCoklat.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_SepatuCoklat.Image")));
            this.pictureBox_SepatuCoklat.Location = new System.Drawing.Point(194, 15);
            this.pictureBox_SepatuCoklat.Name = "pictureBox_SepatuCoklat";
            this.pictureBox_SepatuCoklat.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_SepatuCoklat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_SepatuCoklat.TabIndex = 7;
            this.pictureBox_SepatuCoklat.TabStop = false;
            // 
            // pictureBox_SepatuPutih
            // 
            this.pictureBox_SepatuPutih.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_SepatuPutih.Image")));
            this.pictureBox_SepatuPutih.InitialImage = null;
            this.pictureBox_SepatuPutih.Location = new System.Drawing.Point(22, 15);
            this.pictureBox_SepatuPutih.Name = "pictureBox_SepatuPutih";
            this.pictureBox_SepatuPutih.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_SepatuPutih.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_SepatuPutih.TabIndex = 6;
            this.pictureBox_SepatuPutih.TabStop = false;
            // 
            // panel_longPants
            // 
            this.panel_longPants.Controls.Add(this.btn_AddToCart_LongPantsGrey);
            this.panel_longPants.Controls.Add(this.btn_AddToCart_Brown);
            this.panel_longPants.Controls.Add(this.btn_AddToCart_Black);
            this.panel_longPants.Controls.Add(this.lb_HargaLongPantsGrey);
            this.panel_longPants.Controls.Add(this.lb_HargaBrown);
            this.panel_longPants.Controls.Add(this.lb_HargaBlack);
            this.panel_longPants.Controls.Add(this.lb_longPantsGrey);
            this.panel_longPants.Controls.Add(this.lb_Brown);
            this.panel_longPants.Controls.Add(this.lb_Black);
            this.panel_longPants.Controls.Add(this.pictureBox_longPants_Grey);
            this.panel_longPants.Controls.Add(this.pictureBox_longPantsBrown);
            this.panel_longPants.Controls.Add(this.pictureBox_Black);
            this.panel_longPants.Location = new System.Drawing.Point(27, 49);
            this.panel_longPants.Name = "panel_longPants";
            this.panel_longPants.Size = new System.Drawing.Size(567, 343);
            this.panel_longPants.TabIndex = 25;
            // 
            // btn_AddToCart_LongPantsGrey
            // 
            this.btn_AddToCart_LongPantsGrey.Location = new System.Drawing.Point(368, 281);
            this.btn_AddToCart_LongPantsGrey.Name = "btn_AddToCart_LongPantsGrey";
            this.btn_AddToCart_LongPantsGrey.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_LongPantsGrey.TabIndex = 17;
            this.btn_AddToCart_LongPantsGrey.Text = "Add to Cart";
            this.btn_AddToCart_LongPantsGrey.UseVisualStyleBackColor = true;
            this.btn_AddToCart_LongPantsGrey.Click += new System.EventHandler(this.btn_AddToCart_LongPantsGrey_Click);
            // 
            // btn_AddToCart_Brown
            // 
            this.btn_AddToCart_Brown.Location = new System.Drawing.Point(194, 281);
            this.btn_AddToCart_Brown.Name = "btn_AddToCart_Brown";
            this.btn_AddToCart_Brown.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Brown.TabIndex = 16;
            this.btn_AddToCart_Brown.Text = "Add to Cart";
            this.btn_AddToCart_Brown.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Brown.Click += new System.EventHandler(this.btn_AddToCart_Brown_Click);
            // 
            // btn_AddToCart_Black
            // 
            this.btn_AddToCart_Black.Location = new System.Drawing.Point(22, 281);
            this.btn_AddToCart_Black.Name = "btn_AddToCart_Black";
            this.btn_AddToCart_Black.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Black.TabIndex = 15;
            this.btn_AddToCart_Black.Text = "Add to Cart";
            this.btn_AddToCart_Black.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Black.Click += new System.EventHandler(this.btn_AddToCart_Black_Click);
            // 
            // lb_HargaLongPantsGrey
            // 
            this.lb_HargaLongPantsGrey.AutoSize = true;
            this.lb_HargaLongPantsGrey.Location = new System.Drawing.Point(364, 248);
            this.lb_HargaLongPantsGrey.Name = "lb_HargaLongPantsGrey";
            this.lb_HargaLongPantsGrey.Size = new System.Drawing.Size(96, 20);
            this.lb_HargaLongPantsGrey.TabIndex = 14;
            this.lb_HargaLongPantsGrey.Text = "Rp. 75.000,-";
            // 
            // lb_HargaBrown
            // 
            this.lb_HargaBrown.AutoSize = true;
            this.lb_HargaBrown.Location = new System.Drawing.Point(195, 248);
            this.lb_HargaBrown.Name = "lb_HargaBrown";
            this.lb_HargaBrown.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaBrown.TabIndex = 13;
            this.lb_HargaBrown.Text = "Rp. 120.000,-";
            // 
            // lb_HargaBlack
            // 
            this.lb_HargaBlack.AutoSize = true;
            this.lb_HargaBlack.Location = new System.Drawing.Point(18, 248);
            this.lb_HargaBlack.Name = "lb_HargaBlack";
            this.lb_HargaBlack.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaBlack.TabIndex = 12;
            this.lb_HargaBlack.Text = "Rp. 100.000,-";
            // 
            // lb_longPantsGrey
            // 
            this.lb_longPantsGrey.AutoSize = true;
            this.lb_longPantsGrey.Location = new System.Drawing.Point(364, 208);
            this.lb_longPantsGrey.Name = "lb_longPantsGrey";
            this.lb_longPantsGrey.Size = new System.Drawing.Size(128, 20);
            this.lb_longPantsGrey.TabIndex = 11;
            this.lb_longPantsGrey.Text = "Long Pants Grey";
            // 
            // lb_Brown
            // 
            this.lb_Brown.AutoSize = true;
            this.lb_Brown.Location = new System.Drawing.Point(190, 208);
            this.lb_Brown.Name = "lb_Brown";
            this.lb_Brown.Size = new System.Drawing.Size(139, 20);
            this.lb_Brown.TabIndex = 10;
            this.lb_Brown.Text = "Long Pants Brown";
            // 
            // lb_Black
            // 
            this.lb_Black.AutoSize = true;
            this.lb_Black.Location = new System.Drawing.Point(18, 208);
            this.lb_Black.Name = "lb_Black";
            this.lb_Black.Size = new System.Drawing.Size(133, 20);
            this.lb_Black.TabIndex = 9;
            this.lb_Black.Text = "Long Pants Black";
            // 
            // pictureBox_longPants_Grey
            // 
            this.pictureBox_longPants_Grey.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_longPants_Grey.Image")));
            this.pictureBox_longPants_Grey.Location = new System.Drawing.Point(368, 15);
            this.pictureBox_longPants_Grey.Name = "pictureBox_longPants_Grey";
            this.pictureBox_longPants_Grey.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_longPants_Grey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_longPants_Grey.TabIndex = 8;
            this.pictureBox_longPants_Grey.TabStop = false;
            // 
            // pictureBox_longPantsBrown
            // 
            this.pictureBox_longPantsBrown.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_longPantsBrown.Image")));
            this.pictureBox_longPantsBrown.Location = new System.Drawing.Point(194, 15);
            this.pictureBox_longPantsBrown.Name = "pictureBox_longPantsBrown";
            this.pictureBox_longPantsBrown.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_longPantsBrown.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_longPantsBrown.TabIndex = 7;
            this.pictureBox_longPantsBrown.TabStop = false;
            // 
            // pictureBox_Black
            // 
            this.pictureBox_Black.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Black.Image")));
            this.pictureBox_Black.InitialImage = null;
            this.pictureBox_Black.Location = new System.Drawing.Point(22, 15);
            this.pictureBox_Black.Name = "pictureBox_Black";
            this.pictureBox_Black.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_Black.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Black.TabIndex = 6;
            this.pictureBox_Black.TabStop = false;
            // 
            // panel_jewelleries
            // 
            this.panel_jewelleries.Controls.Add(this.btn_AddToCart_Gold);
            this.panel_jewelleries.Controls.Add(this.btn_AddToCartNecklaceChain);
            this.panel_jewelleries.Controls.Add(this.btn_AddToCart_Silver);
            this.panel_jewelleries.Controls.Add(this.lb_HargaGold);
            this.panel_jewelleries.Controls.Add(this.lb_necklaceChain);
            this.panel_jewelleries.Controls.Add(this.lb_HargaSilver);
            this.panel_jewelleries.Controls.Add(this.lb_Gold);
            this.panel_jewelleries.Controls.Add(this.lb_Chain);
            this.panel_jewelleries.Controls.Add(this.lb_Silver);
            this.panel_jewelleries.Controls.Add(this.lb_GoldNecklaces);
            this.panel_jewelleries.Controls.Add(this.pictureBox9);
            this.panel_jewelleries.Controls.Add(this.pictureBox_Silver);
            this.panel_jewelleries.Location = new System.Drawing.Point(27, 49);
            this.panel_jewelleries.Name = "panel_jewelleries";
            this.panel_jewelleries.Size = new System.Drawing.Size(623, 368);
            this.panel_jewelleries.TabIndex = 26;
            // 
            // btn_AddToCart_Gold
            // 
            this.btn_AddToCart_Gold.Location = new System.Drawing.Point(368, 281);
            this.btn_AddToCart_Gold.Name = "btn_AddToCart_Gold";
            this.btn_AddToCart_Gold.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Gold.TabIndex = 17;
            this.btn_AddToCart_Gold.Text = "Add to Cart";
            this.btn_AddToCart_Gold.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Gold.Click += new System.EventHandler(this.btn_AddToCart_Gold_Click);
            // 
            // btn_AddToCartNecklaceChain
            // 
            this.btn_AddToCartNecklaceChain.Location = new System.Drawing.Point(194, 281);
            this.btn_AddToCartNecklaceChain.Name = "btn_AddToCartNecklaceChain";
            this.btn_AddToCartNecklaceChain.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCartNecklaceChain.TabIndex = 16;
            this.btn_AddToCartNecklaceChain.Text = "Add to Cart";
            this.btn_AddToCartNecklaceChain.UseVisualStyleBackColor = true;
            this.btn_AddToCartNecklaceChain.Click += new System.EventHandler(this.btn_AddToCartNecklaceChain_Click);
            // 
            // btn_AddToCart_Silver
            // 
            this.btn_AddToCart_Silver.Location = new System.Drawing.Point(22, 281);
            this.btn_AddToCart_Silver.Name = "btn_AddToCart_Silver";
            this.btn_AddToCart_Silver.Size = new System.Drawing.Size(101, 52);
            this.btn_AddToCart_Silver.TabIndex = 15;
            this.btn_AddToCart_Silver.Text = "Add to Cart";
            this.btn_AddToCart_Silver.UseVisualStyleBackColor = true;
            this.btn_AddToCart_Silver.Click += new System.EventHandler(this.btn_AddToCart_Silver_Click);
            // 
            // lb_HargaGold
            // 
            this.lb_HargaGold.AutoSize = true;
            this.lb_HargaGold.Location = new System.Drawing.Point(364, 248);
            this.lb_HargaGold.Name = "lb_HargaGold";
            this.lb_HargaGold.Size = new System.Drawing.Size(118, 20);
            this.lb_HargaGold.TabIndex = 14;
            this.lb_HargaGold.Text = "Rp. 2.000.000,-";
            // 
            // lb_necklaceChain
            // 
            this.lb_necklaceChain.AutoSize = true;
            this.lb_necklaceChain.Location = new System.Drawing.Point(195, 248);
            this.lb_necklaceChain.Name = "lb_necklaceChain";
            this.lb_necklaceChain.Size = new System.Drawing.Size(118, 20);
            this.lb_necklaceChain.TabIndex = 13;
            this.lb_necklaceChain.Text = "Rp. 1.000.000,-";
            // 
            // lb_HargaSilver
            // 
            this.lb_HargaSilver.AutoSize = true;
            this.lb_HargaSilver.Location = new System.Drawing.Point(18, 248);
            this.lb_HargaSilver.Name = "lb_HargaSilver";
            this.lb_HargaSilver.Size = new System.Drawing.Size(105, 20);
            this.lb_HargaSilver.TabIndex = 12;
            this.lb_HargaSilver.Text = "Rp. 500.000,-";
            // 
            // lb_Gold
            // 
            this.lb_Gold.AutoSize = true;
            this.lb_Gold.Location = new System.Drawing.Point(364, 208);
            this.lb_Gold.Name = "lb_Gold";
            this.lb_Gold.Size = new System.Drawing.Size(112, 20);
            this.lb_Gold.TabIndex = 11;
            this.lb_Gold.Text = "Gold Necklace";
            // 
            // lb_Chain
            // 
            this.lb_Chain.AutoSize = true;
            this.lb_Chain.Location = new System.Drawing.Point(190, 208);
            this.lb_Chain.Name = "lb_Chain";
            this.lb_Chain.Size = new System.Drawing.Size(119, 20);
            this.lb_Chain.TabIndex = 10;
            this.lb_Chain.Text = "Chain Necklace";
            // 
            // lb_Silver
            // 
            this.lb_Silver.AutoSize = true;
            this.lb_Silver.Location = new System.Drawing.Point(18, 208);
            this.lb_Silver.Name = "lb_Silver";
            this.lb_Silver.Size = new System.Drawing.Size(116, 20);
            this.lb_Silver.TabIndex = 9;
            this.lb_Silver.Text = "Silver Necklace";
            // 
            // lb_GoldNecklaces
            // 
            this.lb_GoldNecklaces.Image = ((System.Drawing.Image)(resources.GetObject("lb_GoldNecklaces.Image")));
            this.lb_GoldNecklaces.Location = new System.Drawing.Point(368, 15);
            this.lb_GoldNecklaces.Name = "lb_GoldNecklaces";
            this.lb_GoldNecklaces.Size = new System.Drawing.Size(127, 175);
            this.lb_GoldNecklaces.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.lb_GoldNecklaces.TabIndex = 8;
            this.lb_GoldNecklaces.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(194, 15);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(127, 175);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 7;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox_Silver
            // 
            this.pictureBox_Silver.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_Silver.Image")));
            this.pictureBox_Silver.InitialImage = null;
            this.pictureBox_Silver.Location = new System.Drawing.Point(22, 15);
            this.pictureBox_Silver.Name = "pictureBox_Silver";
            this.pictureBox_Silver.Size = new System.Drawing.Size(127, 175);
            this.pictureBox_Silver.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_Silver.TabIndex = 6;
            this.pictureBox_Silver.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1217, 759);
            this.Controls.Add(this.panel_Tshirt);
            this.Controls.Add(this.textBox_Total);
            this.Controls.Add(this.textBox_SubTotal);
            this.Controls.Add(this.lb_Total);
            this.Controls.Add(this.lb_SubTotal);
            this.Controls.Add(this.dataGridView_TokoPakaian);
            this.Controls.Add(this.panel_longPants);
            this.Controls.Add(this.panel_jewelleries);
            this.Controls.Add(this.panel_Pants);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel_Shirt);
            this.Controls.Add(this.panel_Shoes);
            this.Controls.Add(this.panel_Upload);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "UNIQME";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_TokoPakaian)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_KerahBulat)).EndInit();
            this.panel_Tshirt.ResumeLayout(false);
            this.panel_Tshirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_VNeck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_AlRism)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_UploadImage)).EndInit();
            this.panel_Upload.ResumeLayout(false);
            this.panel_Upload.PerformLayout();
            this.panel_Shirt.ResumeLayout(false);
            this.panel_Shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Grey)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel_Pants.ResumeLayout(false);
            this.panel_Pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Green)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Pink)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Yellow)).EndInit();
            this.panel_Shoes.ResumeLayout(false);
            this.panel_Shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SepatuPink)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SepatuCoklat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_SepatuPutih)).EndInit();
            this.panel_longPants.ResumeLayout(false);
            this.panel_longPants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longPants_Grey)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_longPantsBrown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Black)).EndInit();
            this.panel_jewelleries.ResumeLayout(false);
            this.panel_jewelleries.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lb_GoldNecklaces)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_Silver)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView_TokoPakaian;
        private System.Windows.Forms.Label lb_SubTotal;
        private System.Windows.Forms.Label lb_Total;
        private System.Windows.Forms.TextBox textBox_SubTotal;
        private System.Windows.Forms.TextBox textBox_Total;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox_KerahBulat;
        private System.Windows.Forms.Panel panel_Tshirt;
        private System.Windows.Forms.Label lb_KerahBulat;
        private System.Windows.Forms.PictureBox pictureBox_VNeck;
        private System.Windows.Forms.PictureBox pictureBox_AlRism;
        private System.Windows.Forms.Label lb_HargaKerahBulat;
        private System.Windows.Forms.Label lb_VNeck;
        private System.Windows.Forms.Label lb_AlRism;
        private System.Windows.Forms.Button btn_AddToCartVNeck;
        private System.Windows.Forms.Button btn_AddToCartAlRism;
        private System.Windows.Forms.Button btn_AddToCart_KerahBulat;
        private System.Windows.Forms.Label lb_HargaVNeck;
        private System.Windows.Forms.Label lb_HargaAlRism;
        private System.Windows.Forms.Label lb_Upload;
        private System.Windows.Forms.Button btn_Upload;
        private System.Windows.Forms.PictureBox pictureBox_UploadImage;
        private System.Windows.Forms.Label lb_ItemName;
        private System.Windows.Forms.Label lb_ItemPrice;
        private System.Windows.Forms.Button btn_AddToCartUpload;
        private System.Windows.Forms.TextBox textBox_ItemName;
        private System.Windows.Forms.TextBox textBox_ItemPrice;
        private System.Windows.Forms.Panel panel_Upload;
        private System.Windows.Forms.Panel panel_Shirt;
        private System.Windows.Forms.Button btn_AddToCart_Grey;
        private System.Windows.Forms.Button btn_AddToCart_Red;
        private System.Windows.Forms.Button btn_AddToCart_DarkBlue;
        private System.Windows.Forms.Label lb_HargaGrey;
        private System.Windows.Forms.Label lb_HargaRed;
        private System.Windows.Forms.Label lb_HargaDarkBlue;
        private System.Windows.Forms.Label lb_Grey;
        private System.Windows.Forms.Label lb_Red;
        private System.Windows.Forms.Label lb_DarkBlue;
        private System.Windows.Forms.PictureBox pictureBox_Grey;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Panel panel_Pants;
        private System.Windows.Forms.Button btn_AddToCart_Green;
        private System.Windows.Forms.Button btn_AddToCart_Pink;
        private System.Windows.Forms.Button btn_AddToCart_Yellow;
        private System.Windows.Forms.Label lb_HargaGreen;
        private System.Windows.Forms.Label lb_HargaPink;
        private System.Windows.Forms.Label lb_HargaYellow;
        private System.Windows.Forms.Label lb_Green;
        private System.Windows.Forms.Label lb_Pink;
        private System.Windows.Forms.Label lb_Yellow;
        private System.Windows.Forms.PictureBox pictureBox_Green;
        private System.Windows.Forms.PictureBox pictureBox_Pink;
        private System.Windows.Forms.PictureBox pictureBox_Yellow;
        private System.Windows.Forms.Panel panel_longPants;
        private System.Windows.Forms.Button btn_AddToCart_LongPantsGrey;
        private System.Windows.Forms.Button btn_AddToCart_Brown;
        private System.Windows.Forms.Button btn_AddToCart_Black;
        private System.Windows.Forms.Label lb_HargaLongPantsGrey;
        private System.Windows.Forms.Label lb_HargaBrown;
        private System.Windows.Forms.Label lb_HargaBlack;
        private System.Windows.Forms.Label lb_longPantsGrey;
        private System.Windows.Forms.Label lb_Brown;
        private System.Windows.Forms.Label lb_Black;
        private System.Windows.Forms.PictureBox pictureBox_longPants_Grey;
        private System.Windows.Forms.PictureBox pictureBox_longPantsBrown;
        private System.Windows.Forms.PictureBox pictureBox_Black;
        private System.Windows.Forms.Panel panel_Shoes;
        private System.Windows.Forms.Button btn_AddToCart_SneakersPink;
        private System.Windows.Forms.Button btn_SneakersCoklat;
        private System.Windows.Forms.Button btn_AddToCard_SneakersPutih;
        private System.Windows.Forms.Label lb_HargaSnekaersPink;
        private System.Windows.Forms.Label lb_HargaSneakersCoklat;
        private System.Windows.Forms.Label lb_HargaSneakersPutih;
        private System.Windows.Forms.Label lb_SneakersPink;
        private System.Windows.Forms.Label lb_SneakersCoklat;
        private System.Windows.Forms.Label lb_SneakersWhite;
        private System.Windows.Forms.PictureBox pictureBox_SepatuPink;
        private System.Windows.Forms.PictureBox pictureBox_SepatuCoklat;
        private System.Windows.Forms.PictureBox pictureBox_SepatuPutih;
        private System.Windows.Forms.Panel panel_jewelleries;
        private System.Windows.Forms.Button btn_AddToCart_Gold;
        private System.Windows.Forms.Button btn_AddToCartNecklaceChain;
        private System.Windows.Forms.Button btn_AddToCart_Silver;
        private System.Windows.Forms.Label lb_HargaGold;
        private System.Windows.Forms.Label lb_necklaceChain;
        private System.Windows.Forms.Label lb_HargaSilver;
        private System.Windows.Forms.Label lb_Gold;
        private System.Windows.Forms.Label lb_Chain;
        private System.Windows.Forms.Label lb_Silver;
        private System.Windows.Forms.PictureBox lb_GoldNecklaces;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox_Silver;
    }
}

