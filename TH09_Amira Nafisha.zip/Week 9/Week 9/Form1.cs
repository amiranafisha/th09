﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_9
{
    public partial class Form1 : Form
    {
        private int count = 1;
        private DataTable dt = new DataTable();

        Dictionary<string, decimal> daftarProduk = new Dictionary<string, decimal>();
        public Form1()
        {
            InitializeComponent();
            daftarProduk.Add("T-Shirt Kerah Bulat", 120000m);
            daftarProduk.Add("AlRism T-Shirt", 150000m);
            daftarProduk.Add("T-Shirt VNeck", 170000m);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel_Tshirt.Visible = false;
            panel_Upload.Visible = false;
            panel_Shirt.Visible = false;
            panel_Pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelleries.Visible = false;

            dt = new DataTable();
            dt.Columns.Add("Item Name");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Price");
            dt.Columns.Add("Total");

            dataGridView_TokoPakaian.DataSource = dt;

            dataGridView_TokoPakaian.CellValueChanged += DataGridView_TokoPakaian_CellValueChanged;

            DataGridViewButtonColumn deleteButtonColumn = new DataGridViewButtonColumn();
            deleteButtonColumn.Name = "btn_Delete";
            deleteButtonColumn.HeaderText = "Delete";
            deleteButtonColumn.Text = "Delete";
            deleteButtonColumn.UseColumnTextForButtonValue = true;
            dataGridView_TokoPakaian.Columns.Add(deleteButtonColumn);
        }

        private void DataGridView_TokoPakaian_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            UpdateTotalPrice();
        }

        private void UpdateTotalPrice()
        {
            decimal totalPrice = 0m;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Index != dataGridView_TokoPakaian.Rows.Count - 1 && row.Cells["Total"].Value != null)
                {
                    decimal rowTotal = 0m;
                    if (Decimal.TryParse(row.Cells["Total"].Value.ToString(), out rowTotal))
                    {
                        totalPrice += rowTotal;
                    }
                }
            }

            textBox_Total.Text = totalPrice.ToString("C");

            UpdateSubTotal();
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Shirt.Visible = false;
            panel_Pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelleries.Visible = false;
            panel_Upload.Visible = false;
            panel_Tshirt.Visible = true;

            ToolStripMenuItem menuItem = sender as ToolStripMenuItem;
            if (menuItem != null)
            {
                string namaProduk = menuItem.Text;
                if (daftarProduk.ContainsKey(namaProduk))
                {
                    decimal hargaProduk = daftarProduk[namaProduk];
                    dataGridView_TokoPakaian.Rows.Add(namaProduk, hargaProduk);
                }
            }
        }

        int quantityKerahBulat = 0;
        decimal totalHargaKerahBulat = 0;
        private void btn_AddToCart_KerahBulat_Click(object sender, EventArgs e)
        {
            decimal harga = 120000;
            quantityKerahBulat++;
            totalHargaKerahBulat = harga * quantityKerahBulat;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_KerahBulat.Text)
                {
                    row.Cells[1].Value = quantityKerahBulat;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaKerahBulat);
                    ada = true;
                    break;
                }
            }

            if (ada == false)
            {
                dt.Rows.Add("T-Shirt Kerah Bulat", quantityKerahBulat, ConvertToRp(harga), TotalHargaBarang(totalHargaKerahBulat));
                dt.Rows[dt.Rows.Count - 1]["Total"] = totalHargaKerahBulat;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityAlRism = 0;
        decimal totalHargaAlRism = 0;
        private void btn_AddToCartAlRism_Click(object sender, EventArgs e)
        {
            decimal harga = 150000;

            quantityAlRism++;
            totalHargaAlRism = harga * quantityAlRism;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_AlRism.Text)
                {
                    row.Cells[1].Value = quantityAlRism;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaAlRism);
                    ada = true;
                    break;
                }
            }

            if (ada == false)
            {
                dt.Rows.Add("AlRism T-Shirt", quantityAlRism, ConvertToRp(harga), TotalHargaBarang(totalHargaAlRism));
                dt.Rows[dt.Rows.Count - 1]["Total"] = totalHargaAlRism;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityVNeck = 0;
        decimal totalHargaVNeck = 0;
        private void btn_AddToCartVNeck_Click(object sender, EventArgs e)
        {
            decimal harga = 150000;
            quantityVNeck++;
            totalHargaVNeck = harga * quantityVNeck;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_VNeck.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityVNeck;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaVNeck);
                    ada = true;
                    break;
                }
            }

            if (ada == false)
            {
                dt.Rows.Add("T-Shirt VNeck", quantityVNeck, ConvertToRp(harga), TotalHargaBarang(totalHargaVNeck));
                dt.Rows[dt.Rows.Count - 1]["Total"] = totalHargaVNeck;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        private void UpdateSubTotal()
        {
            decimal totalHarga = 0m;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Index != dataGridView_TokoPakaian.Rows.Count - 1 && row.Cells["Total"].Value != null)
                {
                    decimal rowTotal = 0m;
                    if (Decimal.TryParse(row.Cells["Total"].Value.ToString(), out rowTotal))
                    {
                        decimal hargaItem = rowTotal / 1.1m;
                        totalHarga += hargaItem;
                    }
                }
            }

            textBox_SubTotal.Text = totalHarga.ToString("C");
        }

        public string ConvertToRp(decimal harga)
        {
            string convert = "Rp." + harga.ToString("C2").Remove(0, 2).Remove(harga.ToString().Length, 3) + ",-";
            return convert;
        }

        public string TotalHargaBarang(decimal totalHarga)
        {
            return ConvertToRp(totalHarga);
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Tshirt.Visible = false;
            panel_Pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelleries.Visible = false;
            panel_Upload.Visible = false;
            panel_Shirt.Visible = true;
        }

        int quantityDarkBlue = 0;
        decimal totalHargaDarkBlue = 0;
        private void btn_AddToCart_DarkBlue_Click(object sender, EventArgs e)
        {
            decimal harga = 42500;
            quantityDarkBlue++;
            totalHargaDarkBlue = harga * quantityDarkBlue;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_DarkBlue.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityDarkBlue;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaDarkBlue);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Polo Shirt DarkBlue", quantityDarkBlue, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityRed = 0;
        decimal totalHargaRed = 0;
        private void btn_AddToCart_Red_Click(object sender, EventArgs e)
        {
            decimal harga = 42500;
            quantityRed++;
            totalHargaRed = harga * quantityRed;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Red.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityRed;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaRed);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Polo Shirt Red", quantityRed, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityGrey = 0;
        decimal totalHargaGrey = 0;
        private void btn_AddToCart_Grey_Click(object sender, EventArgs e)
        {
            decimal harga = 100000; // Harga untuk Dark Blue
            quantityGrey++;
            totalHargaGrey = harga * quantityGrey;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Grey.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityGrey;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaGrey);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Polo Shirt Grey", quantityGrey, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelleries.Visible = false;
            panel_Upload.Visible = false;
            panel_Pants.Visible = true;
        }

        int quantityYellow = 0;
        decimal totalHargaYellow = 0;
        private void btn_AddToCart_Yellow_Click(object sender, EventArgs e)
        {
            decimal harga = 75000;
            quantityYellow++;
            totalHargaYellow = harga * quantityYellow;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Yellow.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityYellow;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaYellow);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Pants Yellow", quantityYellow, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityPink = 0;
        decimal totalHargaPink = 0;
        private void btn_AddToCart_Pink_Click(object sender, EventArgs e)
        {
            decimal harga = 75000;
            quantityPink++;
            totalHargaPink = harga * quantityPink;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Pink.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityPink;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaPink);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Pants Pink", quantityPink, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityGreen = 0;
        decimal totalHargaGreen = 0;
        private void btn_AddToCart_Green_Click(object sender, EventArgs e)
        {
            decimal harga = 75000;
            quantityGreen++;
            totalHargaGreen = harga * quantityGreen;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Green.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityGreen;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaGreen);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Pants Green", quantityGreen, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_Pants.Visible = false;
            panel_jewelleries.Visible = false;
            panel_Shoes.Visible = false;
            panel_Upload.Visible = false;
            panel_longPants.Visible = true;
        }

        int quantityBlack = 0;
        decimal totalHargaBlack = 0;
        private void btn_AddToCart_Black_Click(object sender, EventArgs e)
        {
            decimal harga = 100000;
            quantityBlack++;
            totalHargaBlack = harga * quantityBlack;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Black.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityBlack;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaBlack);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Long Pants Black", quantityBlack, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityBrown = 0;
        decimal totalHargaBrown = 0;
        private void btn_AddToCart_Brown_Click(object sender, EventArgs e)
        {
            decimal harga = 120000;
            quantityBrown++;
            totalHargaBrown = harga * quantityBrown;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Brown.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityBrown;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaBrown);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Long Pants Brown", quantityBrown, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityLPGrey = 0;
        decimal totalHargaLPGrey = 0;
        private void btn_AddToCart_LongPantsGrey_Click(object sender, EventArgs e)
        {
            decimal harga = 75000;
            quantityLPGrey++;
            totalHargaLPGrey = harga * quantityLPGrey;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_longPantsGrey.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityLPGrey;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaLPGrey);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Long Pants Grey", quantityLPGrey, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_Pants.Visible = false;
            panel_longPants.Visible = false;
            panel_jewelleries.Visible = false;
            panel_Upload.Visible = false;
            panel_Shoes.Visible = true;
        }

        int quantityWhite = 0;
        decimal totalHargaWhite = 0;
        private void btn_AddToCard_SneakersPutih_Click(object sender, EventArgs e)
        {
            decimal harga = 200000;
            quantityWhite++;
            totalHargaWhite = harga * quantityWhite;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_SneakersWhite.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityWhite;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaWhite);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Sneakers Putih", quantityWhite, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityCoklat = 0;
        decimal totalHargaCoklat = 0;
        private void btn_SneakersCoklat_Click(object sender, EventArgs e)
        {
            decimal harga = 250000;
            quantityCoklat++;
            totalHargaCoklat = harga * quantityCoklat;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_SneakersCoklat.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityCoklat;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaCoklat);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Sneakers Coklat", quantityCoklat, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantitySPink = 0;
        decimal totalHargaSPink = 0;
        private void btn_AddToCart_SneakersPink_Click(object sender, EventArgs e)
        {
            decimal harga = 300000;
            quantitySPink++;
            totalHargaSPink = harga * quantitySPink;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_SneakersPink.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantitySPink;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaSPink);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Sneakers Pink", quantitySPink, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_Pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_Upload.Visible = false;
            panel_jewelleries.Visible = true;
        }

        int quantitySilver = 0;
        decimal totalHargaSilver = 0;
        private void btn_AddToCart_Silver_Click(object sender, EventArgs e)
        {
            decimal harga = 500000;
            quantitySilver++;
            totalHargaSilver = harga * quantitySilver;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Silver.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantitySilver;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaSilver);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Silver Necklace", quantitySilver, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityNChain = 0;
        decimal totalHargaNChain = 0;
        private void btn_AddToCartNecklaceChain_Click(object sender, EventArgs e)
        {
            decimal harga = 1000000;
            quantityNChain++;
            totalHargaNChain = harga * quantityNChain;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Chain.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityNChain;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaNChain);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Chain Necklace", quantityNChain, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        int quantityGold = 0;
        decimal totalHargaGold = 0;
        private void btn_AddToCart_Gold_Click(object sender, EventArgs e)
        {
            decimal harga = 2000000;
            quantityGold++;
            totalHargaGold = harga * quantityGold;

            bool ada = false;

            foreach (DataGridViewRow row in dataGridView_TokoPakaian.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[0].Value.ToString() == lb_Gold.Text)
                {
                    int jumlah = Convert.ToInt32(row.Cells[1].Value);
                    row.Cells[1].Value = quantityGold;
                    row.Cells[3].Value = TotalHargaBarang(totalHargaGold);
                    ada = true;
                    break;
                }
            }

            if (!ada)
            {
                dt.Rows.Add("Gold Necklace", quantityGold, ConvertToRp(harga), TotalHargaBarang(harga));
                dt.Rows[dt.Rows.Count - 1]["Total"] = harga;
            }

            UpdateTotalPrice();
            UpdateSubTotal();
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_Tshirt.Visible = false;
            panel_Shirt.Visible = false;
            panel_Pants.Visible = false;
            panel_longPants.Visible = false;
            panel_Shoes.Visible = false;
            panel_jewelleries.Visible = false;
            panel_Upload.Visible = true;
        }

        private void btn_Upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            string openedFile = ofd.FileName;

            Image image = Image.FromFile(openedFile);
            pictureBox_UploadImage.Image = image;

            pictureBox_UploadImage.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void textBox_ItemName_TextChanged(object sender, EventArgs e)
        {
            CheckUploadButtonActivation();
        }

        private void textBox_ItemPrice_TextChanged(object sender, EventArgs e)
        {
            CheckUploadButtonActivation();
        }

        private void CheckUploadButtonActivation()
        {
            if (!string.IsNullOrWhiteSpace(textBox_ItemName.Text) && !string.IsNullOrWhiteSpace(textBox_ItemPrice.Text))
            {
                btn_AddToCartUpload.Enabled = true;
            }
            else
            {
                btn_AddToCartUpload.Enabled = false;
            }
        }

        private void btn_AddToCartUpload_Click(object sender, EventArgs e)
        {
            string itemName = textBox_ItemName.Text;
            decimal price = decimal.Parse(textBox_ItemPrice.Text);

            dt.Rows.Add(itemName, ConvertToRp(price), TotalHargaBarang(price));

            UpdateTotalPrice();
            UpdateSubTotal();

            textBox_ItemName.Text = "";
            textBox_ItemPrice.Text = "";

            btn_AddToCartUpload.Enabled = false;

            dt.Rows[dt.Rows.Count - 1]["Total"] = textBox_ItemPrice;

        }

        private void dataGridView_TokoPakaian_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dataGridView_TokoPakaian.Columns["btn_Delete"].Index && e.RowIndex >= 0)
            {
                DialogResult result = MessageBox.Show("Are you sure you want to delete this item?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    dataGridView_TokoPakaian.Rows.RemoveAt(e.RowIndex);

                    UpdateTotalPrice();
                    UpdateSubTotal();
                }
            }
        }
    }
}
